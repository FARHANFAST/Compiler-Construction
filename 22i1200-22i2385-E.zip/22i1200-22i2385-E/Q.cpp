﻿#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <vector>
#include <set>
#include <cctype>
#include <algorithm>
#include <iomanip>

using namespace std;

struct Production {
    string lhs;
    vector<vector<string>> rhs; 
};

class CFGProcessor {
private:
    unordered_map<string, vector<vector<string>>> grammar;
    unordered_map<string, set<string>> firstSets;
    unordered_map<string, set<string>> followSets;
    unordered_map<string, unordered_map<string, vector<string>>> parsingTable;
    string startSymbol;

    vector<string> tokenize(const string& str) {
        vector<string> tokens;
        string token;
        for (char c : str) {
            if (c != ' ') {
                if (c == '(' || c == ')' || c == '+' || c == '*' || c == '|') {
                    if (!token.empty()) {
                        tokens.push_back(token);
                        token.clear();
                    }
                    tokens.push_back(string(1, c));
                }
                else {
                    token += c;
                }
            }
            else if (!token.empty()) {
                tokens.push_back(token);
                token.clear();
            }
        }
        if (!token.empty()) {
            tokens.push_back(token);
        }
        return tokens;
    }

    bool isTerminal(const string& symbol) {
        return grammar.find(symbol) == grammar.end();
    }

    bool hasLeftRecursion() {
        for (const auto& entry : grammar) {
            string nonTerminal = entry.first;
            for (const auto& production : entry.second) {
                if (!production.empty() && production[0] == nonTerminal) {
                    return true;
                }
            }
        }
        return false;
    }

public:
    void readCFG(const string& filename) {
        ifstream file(filename);
        if (!file) {
            throw runtime_error("Unable to open file: " + filename);
        }

        string line;
        bool firstRule = true;
        while (getline(file, line)) {
            if (line.empty()) continue;

            size_t pos = line.find("->");
            if (pos == string::npos) continue;

            string lhs = line.substr(0, pos);
            lhs.erase(remove_if(lhs.begin(), lhs.end(), ::isspace), lhs.end());

            if (firstRule) {
                startSymbol = lhs;
                firstRule = false;
            }

            string rhs = line.substr(pos + 2);
            stringstream ss(rhs);
            string production;

            while (getline(ss, production, '|')) {
                production.erase(remove_if(production.begin(), production.end(), ::isspace), production.end());
                if (!production.empty()) {
                    grammar[lhs].push_back(tokenize(production));
                }
            }
        }
        file.close();
    }

    void performLeftFactoring() {
        bool changed;
        do {
            changed = false;
            unordered_map<string, vector<vector<string>>> newGrammar = grammar;

            for (auto& entry : grammar) {
                string nonTerminal = entry.first;
                vector<vector<string>>& productions = entry.second;

                for (size_t i = 0; i < productions.size(); i++) {
                    for (size_t j = i + 1; j < productions.size(); j++) {
                        vector<string> prefix;
                        size_t k = 0;
                        while (k < productions[i].size() && k < productions[j].size() &&
                            productions[i][k] == productions[j][k]) {
                            prefix.push_back(productions[i][k]);
                            k++;
                        }

                        if (!prefix.empty()) {
                            changed = true;
                            string newNonTerminal = nonTerminal + "'";
                            while (grammar.find(newNonTerminal) != grammar.end()) {
                                newNonTerminal += "'";
                            }

                            vector<string> suffix1(productions[i].begin() + k, productions[i].end());
                            vector<string> suffix2(productions[j].begin() + k, productions[j].end());

                            if (suffix1.empty()) suffix1 = { "ε" };
                            if (suffix2.empty()) suffix2 = { "ε" };

                            newGrammar[nonTerminal] = { prefix };
                            prefix.push_back(newNonTerminal);
                            newGrammar[newNonTerminal] = { suffix1, suffix2 };

                            productions.erase(productions.begin() + j);
                            productions.erase(productions.begin() + i);
                            i--;
                            break;
                        }
                    }
                }
            }
            grammar = newGrammar;
        } while (changed);
    }

    void eliminateLeftRecursion() {
        vector<string> nonTerminals;
        for (const auto& entry : grammar) {
            nonTerminals.push_back(entry.first);
        }

        for (size_t i = 0; i < nonTerminals.size(); i++) {
            string Ai = nonTerminals[i];

            for (size_t j = 0; j < i; j++) {
                string Aj = nonTerminals[j];
                vector<vector<string>> newProductions;

                for (const auto& production : grammar[Ai]) {
                    if (!production.empty() && production[0] == Aj) {
                        for (const auto& AjProd : grammar[Aj]) {
                            vector<string> newProd = AjProd;
                            newProd.insert(newProd.end(),
                                production.begin() + 1,
                                production.end());
                            newProductions.push_back(newProd);
                        }
                    }
                    else {
                        newProductions.push_back(production);
                    }
                }
                grammar[Ai] = newProductions;
            }

            vector<vector<string>> alphas, betas;
            for (const auto& production : grammar[Ai]) {
                if (!production.empty() && production[0] == Ai) {
                    vector<string> alpha(production.begin() + 1, production.end());
                    alphas.push_back(alpha);
                }
                else {
                    betas.push_back(production);
                }
            }

            if (!alphas.empty()) {
                string newNonTerminal = Ai + "'";
                while (grammar.find(newNonTerminal) != grammar.end()) {
                    newNonTerminal += "'";
                }

                vector<vector<string>> newAiProductions;
                for (const auto& beta : betas) {
                    vector<string> newProd = beta;
                    if (beta != vector<string>{"ε"}) {
                        newProd.push_back(newNonTerminal);
                    }
                    newAiProductions.push_back(newProd);
                }
                grammar[Ai] = newAiProductions;

                vector<vector<string>> newNonTerminalProductions;
                for (const auto& alpha : alphas) {
                    vector<string> newProd = alpha;
                    newProd.push_back(newNonTerminal);
                    newNonTerminalProductions.push_back(newProd);
                }
                newNonTerminalProductions.push_back({ "ε" });
                grammar[newNonTerminal] = newNonTerminalProductions;
            }
        }
    }

    set<string> computeFirst(const vector<string>& symbols) {
        set<string> first;
        if (symbols.empty()) {
            first.insert("ε");
            return first;
        }

        string symbol = symbols[0];
        if (isTerminal(symbol)) {
            first.insert(symbol);
        }
        else {
            for (const auto& production : grammar[symbol]) {
                set<string> productionFirst = computeFirst(production);
                first.insert(productionFirst.begin(), productionFirst.end());
            }
        }
        return first;
    }

    void computeAllFirstSets() {
        bool changed;
        do {
            changed = false;
            for (const auto& entry : grammar) {
                string nonTerminal = entry.first;
                set<string> oldFirst = firstSets[nonTerminal];

                for (const auto& production : entry.second) {
                    set<string> productionFirst = computeFirst(production);
                    size_t oldSize = firstSets[nonTerminal].size();
                    firstSets[nonTerminal].insert(productionFirst.begin(), productionFirst.end());
                    if (firstSets[nonTerminal].size() > oldSize) {
                        changed = true;
                    }
                }
            }
        } while (changed);
    }

    void computeAllFollowSets() {
        followSets[startSymbol].insert("$");

        bool changed;
        do {
            changed = false;
            for (const auto& entry : grammar) {
                string nonTerminal = entry.first;
                for (const auto& production : entry.second) {
                    for (size_t i = 0; i < production.size(); i++) {
                        if (!isTerminal(production[i])) {
                            set<string> followSet;

                            if (i < production.size() - 1) {
                                vector<string> remaining(production.begin() + i + 1, production.end());
                                set<string> firstOfRemaining = computeFirst(remaining);

                                for (const string& symbol : firstOfRemaining) {
                                    if (symbol != "ε") {
                                        followSet.insert(symbol);
                                    }
                                }

                                if (firstOfRemaining.find("ε") != firstOfRemaining.end()) {
                                    followSet.insert(followSets[nonTerminal].begin(), followSets[nonTerminal].end());
                                }
                            }
                            else {
                                followSet.insert(followSets[nonTerminal].begin(), followSets[nonTerminal].end());
                            }

                            size_t oldSize = followSets[production[i]].size();
                            followSets[production[i]].insert(followSet.begin(), followSet.end());
                            if (followSets[production[i]].size() > oldSize) {
                                changed = true;
                            }
                        }
                    }
                }
            }
        } while (changed);
    }

    void constructParsingTable() {
        for (const auto& entry : grammar) {
            string nonTerminal = entry.first;
            for (const auto& production : entry.second) {
                set<string> firstOfProduction = computeFirst(production);

                for (const string& terminal : firstOfProduction) {
                    if (terminal != "ε") {
                        if (parsingTable[nonTerminal].find(terminal) != parsingTable[nonTerminal].end()) {
                            throw runtime_error("Grammar is not LL(1): Conflict in parsing table for " +
                                nonTerminal + " and terminal " + terminal);
                        }
                        parsingTable[nonTerminal][terminal] = production;
                    }
                    else {
                        for (const string& followTerminal : followSets[nonTerminal]) {
                            if (parsingTable[nonTerminal].find(followTerminal) != parsingTable[nonTerminal].end()) {
                                throw runtime_error("Grammar is not LL(1): Conflict in parsing table for " +
                                    nonTerminal + " and terminal " + followTerminal);
                            }
                            parsingTable[nonTerminal][followTerminal] = production;
                        }
                    }
                }
            }
        }
    }

    void printGrammar() const {
        cout << "\nGrammar after transformations:\n";
        for (const auto& entry : grammar) {
            cout << entry.first << " -> ";
            for (size_t i = 0; i < entry.second.size(); ++i) {
                for (const string& symbol : entry.second[i]) {
                    cout << symbol << " ";
                }
                if (i < entry.second.size() - 1) cout << "| ";
            }
            cout << endl;
        }
    }

    void printFirstSets() const {
        cout << "\nFIRST Sets:\n";
        for (const auto& entry : firstSets) {
            cout << "FIRST(" << entry.first << ") = { ";
            for (const auto& symbol : entry.second) {
                cout << symbol << " ";
            }
            cout << "}\n";
        }
    }

    void printFollowSets() const {
        cout << "\nFOLLOW Sets:\n";
        for (const auto& entry : followSets) {
            cout << "FOLLOW(" << entry.first << ") = { ";
            for (const auto& symbol : entry.second) {
                cout << symbol << " ";
            }
            cout << "}\n";
        }
    }

    void printParsingTable() const {
        cout << "\nLL(1) Parsing Table:\n";
        set<string> terminals;
        for (const auto& entry : parsingTable) {
            for (const auto& terminalEntry : entry.second) {
                terminals.insert(terminalEntry.first);
            }
        }

        cout << setw(10) << "";
        for (const string& terminal : terminals) {
            cout << setw(15) << terminal;
        }
        cout << endl;

        for (const auto& entry : parsingTable) {
            cout << setw(10) << entry.first;
            for (const string& terminal : terminals) {
                if (entry.second.find(terminal) != entry.second.end()) {
                    string production;
                    for (const string& symbol : entry.second.at(terminal)) {
                        production += symbol + " ";
                    }
                    cout << setw(15) << production;
                }
                else {
                    cout << setw(15) << "";
                }
            }
            cout << endl;
        }
    }
};

int main() {
    try {
        CFGProcessor processor;

        processor.readCFG("cfg.txt");

        processor.performLeftFactoring();
        processor.eliminateLeftRecursion();

        processor.computeAllFirstSets();
        processor.computeAllFollowSets();
        processor.constructParsingTable();

        processor.printGrammar();
        processor.printFirstSets();
        processor.printFollowSets();
        processor.printParsingTable();

    }
    catch (const exception& e) {
        cerr << "Error: " << e.what() << endl;
        return 1;
    }

    return 0;
}