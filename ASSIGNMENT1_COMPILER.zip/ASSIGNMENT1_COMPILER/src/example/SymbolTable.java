package example;
import java.io.*;
import java.util.*;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

public class SymbolTable {
    private Map<String, String> table = new HashMap<>();
    private Set<String> globalVariables = new HashSet<>();
    private Set<String> localVariables = new HashSet<>();
    private Stack<Boolean> scopeStack = new Stack<>();
    private boolean inGlobalScope = true;
    private final Set<String> dataTypes = new HashSet<>(Arrays.asList("integer", "decimal", "character", "boolean"));

    public void processTokens(List<String> tokens) {
        String lastDataType = null;

        for (String token : tokens) {
            if (token.equals("{")) {
                scopeStack.push(inGlobalScope);
                inGlobalScope = false; // Entering a new scope
            } else if (token.equals("}")) {
                if (!scopeStack.isEmpty()) {
                    inGlobalScope = scopeStack.pop(); // Exiting scope
                }
            } else if (token.matches("[()\\[\\]]")) {  
                // Ignore invalid brackets in scope management
                continue;
            } else if (dataTypes.contains(token)) {
                lastDataType = token; // Store last datatype for upcoming variable
            } else if (token.matches("[a-z]+")) { // Identifier
                if (lastDataType != null) { // This token is a variable declaration
                    if (inGlobalScope) {
                        table.put(token, "Global " + lastDataType);
                        globalVariables.add(token);
                    } else {
                        table.put(token, "Local " + lastDataType);
                        localVariables.add(token);
                    }
                    lastDataType = null; // Reset after usage
                }
            }
        }

        System.out.println("Symbol Table: " + table);
        System.out.println("Global Variables: " + globalVariables);
        System.out.println("Local Variables: " + localVariables);
    }
}
