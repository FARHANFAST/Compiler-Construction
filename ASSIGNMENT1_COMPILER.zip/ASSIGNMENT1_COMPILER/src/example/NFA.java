package example;
import java.io.*;
import java.util.*;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

public class NFA {
    private Map<Integer, Map<Character, List<Integer>>> transitionTable = new HashMap<>();
    private int stateCount = 0;
    
    public void convertFromRE(RegularExpression re) {
        System.out.println("Converting RE to NFA for: " + re.getRegex());
        buildNFA(re.getRegex());
    }
    
    public void buildNFA(String regex) {
        stateCount = regex.length() + 1;
        for (int i = 0; i < regex.length(); i++) {
            char c = regex.charAt(i);
            transitionTable.putIfAbsent(i, new HashMap<>());
            transitionTable.get(i).putIfAbsent(c, new ArrayList<>());
            transitionTable.get(i).get(c).add(i + 1);
        }
    }
    
    public int getStateCount() {
        return stateCount;
    }
    
    public Map<Integer, Map<Character, List<Integer>>> getTransitionTable() {
        return transitionTable;
    }
}
