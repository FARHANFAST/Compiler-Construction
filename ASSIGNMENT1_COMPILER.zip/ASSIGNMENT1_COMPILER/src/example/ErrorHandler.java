package example;
import java.io.*;
import java.util.*;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

public class ErrorHandler {
    private static final Set<String> validDataTypes = new HashSet<>(Arrays.asList("integer", "decimal", "character", "boolean"));

    public void checkErrors(List<String> tokens) {
        boolean inMultilineComment = false;
        int commentStartIndex = -1;
        for (int i = 0; i < tokens.size(); i++) {
            String token = tokens.get(i).trim();
            
            // Handle multiline comments: comments start and end with "///"
            if (token.equals("///")) {
                if (!inMultilineComment) {
                    commentStartIndex = i;
                } else if (commentStartIndex == -1) {
                    System.out.println("Error: Closing multiline comment '///' without an opening.");
                }
                inMultilineComment = !inMultilineComment;
                continue;
            }
            if (inMultilineComment) {
                continue; // Skip tokens inside a multiline comment
            }
            
            // Check for datatype declarations.
            // If the next token is an identifier (one or more lowercase letters), then current token should be a valid datatype.
            if (i + 1 < tokens.size() && tokens.get(i + 1).matches("^[a-z]+$")) {
                if (!validDataTypes.contains(token)) {
                    System.out.println("Error: Unrecognized! '" + token + "'");
                    continue;
                }
            }
            
            // Detect unrecognized tokens.
            // Allowed tokens: valid datatypes, identifiers, numbers (with optional decimals), operators, punctuation,
            // curly braces, boolean literals, and a character literal (a single lowercase letter in single quotes).
            // Using anchors (^) and ($) to match the entire token.
            if (!token.matches("^(?:(integer|decimal|character|boolean)|[a-z]+|[0-9]+(?:\\.[0-9]{1,5})?|[+\\-*/%^=();{}]|true|false|'[a-z]')$")) {
                System.out.println("Error: Unrecognized! '" + token + "'");
            }
            
            // Detect invalid brackets (flag only parentheses and square brackets)
            if (token.matches("^[()\\[\\]]$")) {
                System.out.println("Error: Invalid bracket '" + token + "'. Only '{' and '}' are allowed for scope definition.");
            }
            
            // Ensure modulus operator '%' has integer operands.
            if (token.equals("%") && i > 0 && i < tokens.size() - 1) {
                String leftOperand = tokens.get(i - 1);
                String rightOperand = tokens.get(i + 1);
                if (leftOperand.matches("^[0-9]+\\.[0-9]+$") || rightOperand.matches("^[0-9]+\\.[0-9]+$")) {
                    System.out.println("Error: Modulus '%' operator requires integer operands, but found decimal value(s).");
                }
            }
            
            // Ensure proper assignments:
            // If token is "=" and the two tokens before form a valid declaration,
            // then check that the assigned value is valid for that datatype.
            if (token.equals("=") && i > 1 && validDataTypes.contains(tokens.get(i - 2))) {
                String varType = tokens.get(i - 2);
                String assignedValue = (i + 1 < tokens.size()) ? tokens.get(i + 1) : "";
                
                if (varType.equals("integer") && assignedValue.matches("^[0-9]+\\.[0-9]+$")) {
                    System.out.println("Error: Integer variable '" + tokens.get(i - 1)
                        + "' cannot be assigned a decimal value: '" + assignedValue + "'");
                }
                if (varType.equals("character") && !assignedValue.matches("^'[a-z]'$")) {
                    System.out.println("Error: Character variable must contain exactly one lowercase character inside single quotes: '"
                        + assignedValue + "'");
                }
                if (varType.equals("boolean") && !assignedValue.matches("^(true|false)$")) {
                    System.out.println("Error: Boolean variable must be assigned only 'true' or 'false': '"
                        + assignedValue + "'");
                }
            }
        }
        
        // If a multiline comment was opened but not closed, show an error.
        if (inMultilineComment) {
            System.out.println("Error: Multiline comment '///' was opened but never closed.");
        }
    }
}
