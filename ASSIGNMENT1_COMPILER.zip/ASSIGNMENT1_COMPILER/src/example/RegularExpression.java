package example;
import java.io.*;
import java.util.*;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

public class RegularExpression {
    private String regex;
    
    public void buildRE() {
    	regex = "(integer|decimal|character|boolean)|[a-z]+|\\d+(\\.\\d{1,5})?|[+\\-*/%^=();]|true|false|'.'";
        System.out.println("Regular Expression built: " + regex);
    }
    public String getRegex() {
        return regex;
    }
}
