package example;
import java.io.*;
import java.util.*;
import java.util.ArrayList;
import java.util.List;

public class LexicalAnalyzer {
    private List<String> tokens = new ArrayList<>();
    
    public void tokenize(File file) {
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Remove single-line comments and block comments
                line = line.replaceAll("//.*", "").replaceAll("/\\*.*?\\*/", "");
                
                // Updated token splitting: include curly braces as separate tokens by escaping them properly.
                String[] splitTokens = line.trim().split("(?=[+\\-*/%^=();\\{\\}])|(?<=[+\\-*/%^=();\\{\\}])|\\s+");
                
                for (String token : splitTokens) {
                    if (!token.isBlank()) {
                        tokens.add(token.trim());
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        System.out.println("Tokens generated: " + tokens);
    }
    
    public List<String> getTokens() {
        return tokens;
    }
}
