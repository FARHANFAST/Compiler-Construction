package example;
import java.io.*;
import java.util.*;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

public class DFA {
	private Map<Integer, Map<Character, Integer>> transitionTable = new HashMap<>();
    private int stateCount = 0;
    
    public void convertFromNFA(NFA nfa) {
        System.out.println("Converting NFA to DFA...");
        buildDFA(nfa.getTransitionTable(), nfa.getStateCount());
    }
    
    public void buildDFA(Map<Integer, Map<Character, List<Integer>>> nfaTable, int nfaStates) {
        stateCount = nfaStates;
        for (int i = 0; i < nfaStates; i++) {
            transitionTable.putIfAbsent(i, new HashMap<>());
            for (char c : nfaTable.getOrDefault(i, new HashMap<>()).keySet()) {
                int nextState = nfaTable.get(i).get(c).get(0);
                transitionTable.get(i).put(c, nextState);
            }
        }
    }
    
    public void displayTransitionTable() {
        System.out.println("DFA Transition Table:");
        for (Map.Entry<Integer, Map<Character, Integer>> entry : transitionTable.entrySet()) {
            System.out.println("State " + entry.getKey() + " -> " + entry.getValue());
        }
    }
}
