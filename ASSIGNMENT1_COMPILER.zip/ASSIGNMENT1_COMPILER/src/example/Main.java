package example;

import java.io.*;
import java.util.*;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        String filePath = "test.txt";
        
        if (!filePath.endsWith(".txt")) {
            System.out.println("Error: Unsupported file extension. Only .txt files are allowed.");
            return;
        }
        
        File inputFile = new File(filePath);
        if (!inputFile.exists()) {
            System.out.println("Error: File not found.");
            return;
        }
        
        RegularExpression re = new RegularExpression();
        NFA nfa = new NFA();
        DFA dfa = new DFA();
        LexicalAnalyzer lexer = new LexicalAnalyzer();
        SymbolTable symbolTable = new SymbolTable();
        ErrorHandler errorHandler = new ErrorHandler();
        
        re.buildRE();
        nfa.convertFromRE(re);
        dfa.convertFromNFA(nfa);
        lexer.tokenize(inputFile);
        symbolTable.processTokens(lexer.getTokens());
        errorHandler.checkErrors(lexer.getTokens());
        
        dfa.displayTransitionTable();
    }
}
